import 'package:flutter/material.dart';

class UserFormScreen extends StatelessWidget {
  const UserFormScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Form Page'),
          elevation: 0,
        ),
        body: Center(
            widthFactor: 30,
            child: Card(
                color: const Color.fromARGB(255, 252, 237, 237),
                child: Form(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[
                      const Padding(
                          padding: EdgeInsets.all(20),
                          child: Text('Form', style: TextStyle(fontSize: 25))),

                      //Nombre
                      Padding(
                        padding: const EdgeInsets.all(20),
                        child: TextFormField(
                          decoration: const InputDecoration(
                              labelText: 'Name',
                              border: OutlineInputBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(3.0)))),
                        ),
                      ),
                      //Apellido
                      Padding(
                        padding: const EdgeInsets.all(20),
                        child: TextFormField(
                          decoration: const InputDecoration(
                              labelText: 'LastName',
                              border: OutlineInputBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(3.0)))),
                        ),
                      ),

                      //Correo
                      Padding(
                        padding: const EdgeInsets.all(20),
                        child: TextFormField(
                          decoration: const InputDecoration(
                              labelText: 'Email',
                              border: OutlineInputBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(3.0)))),
                        ),
                      ),

                      //Password
                      Padding(
                        padding: const EdgeInsets.all(20),
                        child: TextFormField(
                          obscureText: true,
                          decoration: const InputDecoration(
                              labelText: 'Password',
                              border: OutlineInputBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(3.0)))),
                        ),
                      ),

                      ClipRRect(
                        child: Stack(
                          children: <Widget>[
                            Positioned.fill(
                                child: Container(
                              decoration: const BoxDecoration(
                                  gradient: LinearGradient(colors: <Color>[
                                Color.fromARGB(255, 114, 146, 0),
                                Color.fromARGB(255, 104, 202, 84),
                                Color.fromARGB(255, 115, 255, 0),
                              ])),
                            )),
                            TextButton(
                                style: TextButton.styleFrom(
                                  padding: const EdgeInsets.all(16),
                                  primary: const Color.fromARGB(255, 3, 0, 0),
                                  textStyle: const TextStyle(fontSize: 20),
                                ),
                                onPressed: () => {},
                                child: const Text('Submit'))
                          ],
                        ),
                      )
                    ],
                  ),
                ))));
  }
}
