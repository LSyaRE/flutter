import 'package:flutter/material.dart';
import 'package:flutterlistado/widgets/widgets.dart';

import '../themes/theme.dart';

class UserFormScreen extends StatelessWidget {
  const UserFormScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Form Page'),
          elevation: 0,
        ),
        body: Center(
          widthFactor: 30,
          child: Card(
              color: const Color.fromARGB(255, 252, 237, 237),
              child: Form(
                  child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: const <Widget>[
                    CustomInputField(
                      sufixIcon: Icon(Icons.people, color: AppTheme.primary),
                      iconEntry: Icon(Icons.people, color: AppTheme.primary),
                      labelTxt: 'Nombre',
                      autoFocus: true,
                      hintTxt: 'Ingrese el nombre',
                    ),
                    CustomInputField(
                      sufixIcon: Icon(Icons.data_usage_rounded,
                          color: AppTheme.primary),
                      iconEntry: Icon(Icons.data_usage_rounded,
                          color: AppTheme.primary),
                      labelTxt: 'Apellido',
                      hintTxt: 'Ingrese el apellido',
                    ),
                    CustomInputField(
                        sufixIcon: Icon(Icons.mail, color: AppTheme.primary),
                        iconEntry: Icon(Icons.mail, color: AppTheme.primary),
                        labelTxt: 'Correo',
                        hintTxt: 'Ingrese el correo',
                        keyBoardType: TextInputType.emailAddress),
                    CustomInputField(
                      sufixIcon: Icon(Icons.key, color: AppTheme.primary),
                      iconEntry: Icon(Icons.key, color: AppTheme.primary),
                      labelTxt: 'Password',
                      hintTxt: 'Ingrese el password',
                      helperTxt:
                          'Ingrese una password con caracteres especiales',
                      keyBoardType: TextInputType.emailAddress,
                      obscureText: true,
                    ),
                  ],
                ),
              ))),
        ));
  }
}
